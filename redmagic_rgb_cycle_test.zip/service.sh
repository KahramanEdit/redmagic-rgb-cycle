#!/system/bin/sh
# RedMagic AW22XXX RGB Color Cycle - KSU Web UI Dynamic Speed

EFFECT=/sys/devices/platform/soc/ac0000.qcom,qupv3_1_geni_se/a94000.i2c/i2c-5/5-006a/leds/aw22xxx_led/effect
SPEED_FILE=/data/adb/redmagic_rgb_speed.txt

until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done

for i in 1 2 3 4 5; do
    [ -e "$EFFECT" ] && break
    sleep 2
done

if [ ! -e "$EFFECT" ]; then
    exit 1
fi

COLORS="1 9 3 4 5 6 7 8"

PIDFILE=/data/local/tmp/rgb_cycle.pid
if [ -f "$PIDFILE" ]; then
    OLDPID=$(cat "$PIDFILE")
    kill "$OLDPID" 2>/dev/null
fi
echo $$ > "$PIDFILE"

# Dosya yoksa varsayılan hızı (1.5) oluştur
if [ ! -f "$SPEED_FILE" ]; then
    echo "1.5" > "$SPEED_FILE"
fi

while true; do
    # KSU arayüzünden gelen güncel hızı oku
    SPEED=$(cat "$SPEED_FILE" 2>/dev/null)
    if [ -z "$SPEED" ]; then
        SPEED=1.5
    fi

    for c in $COLORS; do
        val=$(printf '0x1%03x%03x' 2 "$c")
        echo "$val" > "$EFFECT" 2>/dev/null
        val=$(printf '0x2%03x%03x' 2 "$c")
        echo "$val" > "$EFFECT" 2>/dev/null
        val=$(printf '0x3%03x%03x' 2 "$c")
        echo "$val" > "$EFFECT" 2>/dev/null
        sleep $SPEED
    done
done &
